<div class="card flex-fill p-3" id="samp">
   <div class="card-header">
      <h5 class="card-title mb-0">Final Actions</h5>
   </div>
   <table class="table table-hover  " id="datatables" style="width: 100%; ">
      <thead>
         <tr>
            <th>#</th>
            <th>Name</th>
            <th>Username</th>
            <th>Address</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>Status</th>
            <th>Actions</th>
         </tr>
      </thead>
   </table>
</div>