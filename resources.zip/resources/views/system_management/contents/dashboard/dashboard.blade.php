@extends('system_management.layout.system_master')
@section('title', $title)
@section('content')
@include('global_includes.title')
@endsection
@section('js')
