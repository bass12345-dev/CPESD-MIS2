<div class="col-md-6">
    <div class="input-group mb-3 ">
        <input type="text" class="form-control pull-right mt-2 mb-2" name="daterange_completed_filter" value=""
            style="height: 45px;" />
        <div class="input-group-append">
            <div class="col-md-12"> <a href="javascript:;" id="reset" class="btn  mb-3 mt-2 sub-button pull-right"><i
                        class="ti-calendar"></i></a>
            </div>
        </div>

    </div>
</div>