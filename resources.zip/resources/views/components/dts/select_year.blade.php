<select class="custom-select form-select form-control" id="admin_year" onchange="load_graph(this)">
@include('components.option')
</select>