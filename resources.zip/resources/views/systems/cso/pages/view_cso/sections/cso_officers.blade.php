<div class="col-md-6">
    <div class="card p-3 border">
        <div class="data-tables">
            <button class="btn sub-button pull-left mb-3 " data-toggle="modal" data-target="#add_officers_modal">Add Officer</button>
            <table id="officers_table" style="width:100%" class="text-center mb-3">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Contact Number</th>
                        <th>Email Address</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>