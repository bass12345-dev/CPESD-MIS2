<div class="col-lg-6 mt-sm-30 mt-xs-30">
    <div class="card">
        <div class="card-body">
            <canvas id="cso-chart" width="800" height="800"></canvas>
        </div>
    </div>
</div>