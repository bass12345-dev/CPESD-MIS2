<div class="col-lg-6 mt-sm-30 mt-xs-30 mt-5">
    <div class="data-tables">
        <table id="per_barangay_table" style="width:100%" class="text-center">
            <thead class="bg-light text-capitalize">
                <tr>
                    <th>Barangay</th>
                    <th>Active</th>
                    <th>Inactive</th>
                </tr>
            </thead>
        </table>
    </div>
</div>