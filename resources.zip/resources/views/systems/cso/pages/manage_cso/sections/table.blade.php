<div class="data-tables">
    <table id="cso_table" style="width:100%" class="text-center">
        <thead class="bg-light text-capitalize">
            <tr>
                <th>Controll No.</th>
                <th>CSO</th>
                <th>Address</th>
                <th>Contact Person</th>
                <th>Contact Number</th>
                <th>Telephone Number</th>
                <th>Email Address</th>
                <th>Classification</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
    </table>
</div>