<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
    <div class="statistic-right-area notika-shadow mg-tb-30 sm-res-mg-t-0">
        <div class="row">
            <h4 class="text-center">Inside Oroquieta</h4>
        </div>
        @include('components.lls.hamster_loader')
        <canvas id="inside-skilled-chart"></canvas>
    </div>
</div>
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
    <div class="statistic-right-area notika-shadow mg-tb-30 sm-res-mg-t-0">
        <div class="row">
            <h4 class="text-center">Outside Oroquieta</h4>
        </div>
        @include('components.lls.hamster_loader')
        <canvas id="outside-skilled-chart" class="outside-skilled-chart"></canvas>
    </div>
</div>