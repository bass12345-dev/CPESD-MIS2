<!-- Data Table area Start-->
<div class="data-table-list">
   
    <div class="table-responsive">
        <table id="nature_table" class="table table-striped">
            <thead>
                <tr>
         
                    <th>Total No. of Skilled Workers</th>
                    <th>Total No. of UnSkilled Workers</th>
                    <th>Over All Total Workers</th>
                </tr>
                <tr>
                    <td class="text-center skilled text-bold"></td>
                    <td class="text-center unskilled text-bold"></td>
                    <td class="text-center total_workers text-bold"></td>
                </tr>
            </thead>
        </table>
    </div>
</div>