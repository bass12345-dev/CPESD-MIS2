<div class="statistic-right-area notika-shadow mg-tb-5 sm-res-mg-t-0">
    <canvas  id="projects-chart"></canvas>
</div>


