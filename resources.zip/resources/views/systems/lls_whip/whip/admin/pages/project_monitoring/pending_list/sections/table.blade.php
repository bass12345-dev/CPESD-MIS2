    <!-- Data Table area Start-->
    <div class="data-table-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="data-table-list">
                        <div class="basic-tb-hd">
                            <h2>{{$title}}</h2>
                            <button class="btn btn-danger multi-delete" id="multi-delete1" >Delete</button>
                            <button class="btn btn-primary multi-delete" onclick="reload()" >Reload</button>
                        </div>
                        <div class="table-responsive">
                            <table id="data-table-basic" class="table table-striped">
                            <thead>
                                    <tr>
                                        <th></th>
                                        <th>#</th>
                                        <th>WHIP Code</th>
                                        <th>Project</th>
                                        <th>Contractor</th>
                                        <th>Address</th>
                                        <th>Date Of Monitoring</th>
                                        <th>Specific Activity</th>
                                        <th>Status</th>
                                        <th>Remarks</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Data Table area End-->