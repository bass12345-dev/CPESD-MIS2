
<script src="{{asset('lls_assets/js/vendor/modernizr-2.8.3.min.js')}}"></script>
<script src="{{asset('lls_assets/js/vendor/jquery-1.12.4.min.js')}}"></script>
<!-- bootstrap JS
		============================================ -->
<script src="{{asset('lls_assets/js/bootstrap.min.js')}}"></script>
<!-- wow JS
		============================================ -->
<script src="{{asset('lls_assets/js/wow.min.js')}}"></script>

<!-- scrollUp JS
		============================================ -->
<script src="{{asset('lls_assets/js/jquery.scrollUp.min.js')}}"></script>
<!-- meanmenu JS
		============================================ -->
<script src="{{asset('lls_assets/js/meanmenu/jquery.meanmenu.js')}}"></script>
<!-- counterup JS
		============================================ -->
<script src="{{asset('lls_assets/js/counterup/jquery.counterup.min.js')}}"></script>
<script src="{{asset('lls_assets/js/counterup/waypoints.min.js')}}"></script>
<script src="{{asset('lls_assets/js/counterup/counterup-active.js')}}"></script>
<!-- mCustomScrollbar JS
		============================================ -->
<script src="{{asset('lls_assets/js/scrollbar/jquery.mCustomScrollbar.concat.min.js')}}"></script>




<script src="{{ asset('assets/css/bootstrap-select/bootstrap-select.js')}}"></script>
<!-- plugins JS
		============================================ -->
<script src="{{asset('lls_assets/js/plugins.js')}}"></script>
<!--  Chat JS
		============================================ -->
<script src="{{asset('lls_assets/js/moment.min.js')}}"></script>

<!-- main JS
		============================================ -->
<script src="{{asset('lls_assets/js/main.js')}}"></script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>

<script src="{{asset('assets/js/datatables.js')}}"></script>
<script src="https://gyrocode.github.io/jquery-datatables-checkboxes/1.2.12/js/dataTables.checkboxes.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script src="https://twitter.github.io/typeahead.js/releases/latest/typeahead.bundle.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.4/dist/sweetalert2.all.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/js-loading-overlay@1.1.0/dist/js-loading-overlay.min.js"></script>
<script src="{{asset('assets/js/yearpicker.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://jsuites.net/v4/jsuites.js"></script>