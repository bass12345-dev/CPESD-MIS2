<div class="notika-status-area " style="margin-bottom: 20px;">
    <div class="container ">
        <div class="row dash" style="margin-bottom: 20px;">
            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 ">
                <div class="wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30 b ">
                    <div class="ag-courses-item bg1 "></div>
                    <div class="website-traffic-ctn">
                        <h2><span class="counter">{{$establishments}}</span></h2>
                        <p>Establishments</p>
                    </div>

                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30 b">
                    <div class="ag-courses-item bg1"></div>
                    <div class="website-traffic-ctn">
                        <h2><span class="counter">{{$positions}}</span></h2>
                        <p>Positions</p>
                    </div>

                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30 b">
                    <div class="ag-courses-item bg2"></div>
                    <div class="website-traffic-ctn">
                        <h2><span class="counter">{{$total_establishment_employee}}</span></h2>
                        <p>Total Establishment Employees</p>
                    </div>

                </div>
            </div>
           
        </div>
       
    </div>
</div>