@extends('systems.lls_whip.lls.user.layout.user_master')
@section('title', $title)
@section('content')
@endsection
@section('js')
@endsection