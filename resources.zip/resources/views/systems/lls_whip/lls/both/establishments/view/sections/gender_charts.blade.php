<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
    <div class="statistic-right-area notika-shadow mg-tb-30 sm-res-mg-t-0">
        <div class="row">
            <h4 class="text-center">Employed Inside Oroquieta</h4>
        </div>
        <canvas id="inside-gender-chart"></canvas>
    </div>
</div>
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
    <div class="statistic-right-area notika-shadow mg-tb-30 sm-res-mg-t-0">
        <div class="row">
            <h4 class="text-center">Employed Outside Oroquieta</h4>
        </div>
        <canvas id="outside-gender-chart"></canvas>
    </div>
</div>