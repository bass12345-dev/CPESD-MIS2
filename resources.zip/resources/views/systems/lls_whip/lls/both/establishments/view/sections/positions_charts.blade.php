<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="statistic-right-area notika-shadow mg-tb-30 sm-res-mg-t-0">
        <div class="row">
            <h4 class="text-center">Employed positions</h4>
        </div>
        <canvas id="positions-chart" ></canvas>
    </div>
</div>