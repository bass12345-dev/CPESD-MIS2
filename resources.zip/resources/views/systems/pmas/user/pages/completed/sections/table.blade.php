<div class="col-md-12">
    <table id="user_completed_transactions_table" class="text-center stripe " style="width: 100%;">
        <thead class="bg-light text-capitalize">
            <tr>
                <th>PMAS NO</th>
                <th>Date & Time Filed</th>
                <th>Type of Activity</th>
                <th>CSO</th>
                <th>Person Responsible</th>
                <th>Action</th>
            </tr>
        </thead>
    </table>
</div>