<div class="col-md-6 ">
    <div class="data-tables">
        @include('systems.pmas.includes.components.view_transaction')
    </div>
</div>