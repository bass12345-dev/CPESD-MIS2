
   <div class="col-12 mt-5">
      <div class="card" style="border: 1px solid;">
         <div class="card-body">
            <div class="row">
               <div class="col-md-12">               
                  <div class="data-tables">
                     <table id="datatables-buttons" style="width:100%" class="text-center">
                        <thead class="bg-light text-capitalize">
                           <tr>
                              <th>#</th>
                              <th>Name</th>
                              <th>User Type</th>
                              <th>Action</th>
                              
                              <th>Date and Time</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
             
            </div>
         </div>
      </div>
   </div>
