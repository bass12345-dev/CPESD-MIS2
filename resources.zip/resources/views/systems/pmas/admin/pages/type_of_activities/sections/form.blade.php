<div class="col-md-6">
   <div class="card">
      <h4 class="header-title">Add Type of Activity</h4>
      <form id="add_activity_form">
         <div class="form-group">
            <div class="col-12">Type of Activity<span class="text-danger">*</span></div>
            <input  type="text" class="form-control input" id="activity" name="activity"  placeholder="" required>      
         </div>
         <button  type="submit" class="btn  mt-1 pr-4 pl-4 btn-add-activity b sub-button"> Submit</button>
         <div class="alert"></div>
      </form>
   </div>
</div>