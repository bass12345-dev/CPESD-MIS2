<div class="col-md-12">
    <div class="data-tables">
        <table id="pending_transactions_table" style="width:100%" class="text-center stripe">
            <thead class="bg-light text-capitalize">
                <tr>
                    <th>PMAS NO</th>
                    <th>Date & Time Filed</th>
                    <!-- <th>Responsible Section</th> -->
                    <th>Type of Activity</th>
                    <!-- <th>Responsibility Center</th>
               <th>Date And Time</th> -->
                    <th>CSO</th>
                    <th>Person Responsible</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
        </table>
    </div>
</div>