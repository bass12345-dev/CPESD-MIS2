<div class="col-md-6">
    <div class="data-tables">
        <table id="responsibility_table" style="width:100%" class="text-center">
            <thead class="bg-light text-capitalize">
                <tr>
                    <th>Responsibilty Center Code</th>
                    <th>Responsibility Center</th>
                    <th>Actions</th>
                </tr>
            </thead>
        </table>
    </div>
</div>