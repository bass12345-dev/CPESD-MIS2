<div class="card flex-fill p-3">
    <div class="card-header">
        <h5 class="card-title mb-2">Documents</h5>
    </div>
    <table class="table table-hover table-striped " id="datatable_with_select" style="width: 100%; ">
        <thead>
            <tr>

                <th>#</th>
                <th>Program</th>
                <th>Program Description</th>
                <th>Created</th>
                <th>Actions</th>

            </tr>
        </thead>

    </table>
</div>