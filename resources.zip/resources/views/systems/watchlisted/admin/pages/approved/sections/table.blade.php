<div class="card flex-fill p-3">
    <div class="card-header">
        <button class="btn btn-danger" id="remove"> Remove</button>
        <hr>
    </div>


    <table class="table table-hover table-striped " id="datatable_with_select" style="width: 100%; ">
        <thead>
            <tr>
                <th></th>
                <!-- <th class=""><input type="checkbox" name="check_all" value="true"></th>    -->
                <th>#</th>
                <th>Name</th>
                <th>Age</th>
                <th>Address</th>
                <th>Email</th>
                <th>Phone Number</th>

            </tr>
        </thead>

    </table>
</div>