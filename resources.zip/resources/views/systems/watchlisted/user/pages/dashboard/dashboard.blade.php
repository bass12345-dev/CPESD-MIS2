@extends('systems.watchlisted.user.layout.user_master')
@section('title', $title)
@section('content')
@include('global_includes.title')
@include('systems.watchlisted.user.pages.dashboard.sections.count1')
@endsection
@section('js')
<script>

</script>
@endsection