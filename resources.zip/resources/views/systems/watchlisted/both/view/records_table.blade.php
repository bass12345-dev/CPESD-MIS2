<div class="card flex-fill p-3">
    <table class="table table-hover table-striped " id="datatable_with_select" style="width: 100%; ">
        <thead>
            <tr>
                <th>Record</th>
                <th>Created</th>
                <th>Actions</th>
            </tr>
        </thead>
    </table>
</div>