
<button class="btn sub-button btn-block mt-2 mb-2" style="width: 100%;" id="generate-rfa-report">Generate
    Report</button>
<div id="generate_rfa_report_section" hidden="true">
    <div class="row mt-2">
        <div class="col-md-12">
            <button class="btn  mb-3 mt-2 btn-danger pull-right" id="close_rfa_report_section"><i
                    class="ti-close "></i></button>
        </div>
    </div>
    <div class="row">
        <div class="col-12 mt-2">
            <table id="completed_transactions_table" class="text-center stripe ">
                <thead class="bg-light text-capitalize">
                    <tr>
                        <th>Reference Number</th>
                        <th>Name of Client</th>
                        <th>Complete Address</th>
                        <th>Type of Request</th>
                        <th>Type of Transaction</th>
                        <th>Action</th>



                    </tr>
                </thead>

            </table>
        </div>

    </div>
</div>