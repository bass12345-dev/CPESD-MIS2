<div class="row mt-2">
    <div class="col-lg-12 mt-sm-30 mt-xs-30">
        <div class="card">
            <div class="card-body">
                <canvas id="admin-by-gender-chart" height="100">></canvas>
            </div>
        </div>
    </div>
</div>
