<div class="col-md-12">
    <div class="data-tables">
        <table id="rfa_completed_table" style="width:100%" class="text-center">
            <thead class="bg-light text-capitalize">
                <tr>
                    <th>Reference Number</th>
                    <th>Name of Client</th>
                    <th>Complete Address</th>
                    <th>Type of Request</th>
                    <th>Type of Transaction</th>

                    <th>Action</th>
                </tr>
            </thead>
        </table>
    </div>
</div>