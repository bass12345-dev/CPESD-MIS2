<div class="col-md-12">
    <div class="data-tables">
        <table id="rfa_clients_table" style="width:100%" class="text-center">
            <thead class="bg-light text-capitalize">
                <tr>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Contact Number</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Employment Status</th>
                    <th>Assisted</th>
                </tr>
            </thead>
        </table>
    </div>
</div>