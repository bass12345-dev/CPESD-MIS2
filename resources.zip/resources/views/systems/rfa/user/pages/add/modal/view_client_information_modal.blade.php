<div class="modal fade" id="view_client_information_modal" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title cso_title">Client Information</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <table class="tablesaw table-bordered table-hover table" data-tablesaw-mode="swipe"
                            data-tablesaw-sortable data-tablesaw-sortable-switch data-tablesaw-minimap
                            data-tablesaw-mode-switch id="_table">

                            <tr>
                                <td>Complete Name</td>
                                <td class="complete_name"></td>
                            </tr>
                            <tr>
                                <td>Address</td>
                                <td class="address"></td>
                            </tr>

                            <tr>
                                <td>Contact Address</td>
                                <td class="contact_number"></td>
                            </tr>

                            <tr>
                                <td>Age</td>
                                <td class="age"></td>
                            </tr>

                            <tr>
                                <td>Employement Status</td>
                                <td class="employment_status"></td>
                            </tr>

                        </table>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>