<div class="col-lg-6 col-md-6 p-3">
    <a href="javascript:;" class="btn sub-button pull-right mt-2 mb-2" id="reload_all_transactions">reload <i
            class="ti-loop"></i></a>
    <table id="request_table" style="width:100%" class="text-center stripe">
        <thead class="bg-light text-capitalize">
            <tr>
                <th>Reference NO</th>
                <th>Date & Time Filed</th>
                <th>Person Responsible</th>
            </tr>
        </thead>
    </table>
</div>