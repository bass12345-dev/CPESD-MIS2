<div class="col-md-6 col-sm-4 clearfix">
    <a href="{{url('/home')}}" class="pull-right text-danger" style="font-size: 20px;">Back to Home</a>
    <ul class="notification-area pull-right mr-3">
        <li class="dropdown">
        </li>
        

    </ul>
</div>