<script type="text/javascript" src="{{ asset('pmas_rfa/bundle.js')}}"></script>
<script type="text/javascript" src="{{ asset('pmas_rfa/datepicker/bootstrap-datetimepicker.min.js')}}"></script>