<div class="row d-none result-card">
  <div class="col-md-12 col-12">
    <div class="card flex-fill p-3">
    <div class="loading"></div>
      <div class="card-header">
      
        <h5 class="card-title text-danger mb-0"></h5>
      </div>
      <div class="data-container"></div>
      <div class="pagination-container mt-3"></div>
    </div>
  </div>
</div>