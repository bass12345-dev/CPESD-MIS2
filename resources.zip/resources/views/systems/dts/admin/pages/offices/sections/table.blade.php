<div class="card flex-fill p-3">
  
   <table class="table table-hover  " id="datatables-buttons" style="width: 100%; ">
      <thead>
         <tr>
            <th>#</th>
            <th>Office</th>
            <th>Created</th>
            <th>Action</th>
         </tr>
      </thead>

   </table>
</div>