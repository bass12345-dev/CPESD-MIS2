<div class="row  d-flex justify-content-center mb-2 ">
  <div class="col-md-8">
    <form id="search_form">
      <div class="search">
        <i class="fa fa-search"></i>
        <input type="text" class="form-control" placeholder="Enter Tracking Number, Document Title" name="search" required>
        <button type="submit" class="btn btn-primary">Search</button>
      </div>
    </form>
  </div>
</div>