<div class="card flex-fill p-3 d-none display_result">
    <div class="card-header">
        <button class="btn btn-success " id="complete">Complete</button>

    </div>
    <table class="table table-hover table-striped " id="datatable_with_select" style="width: 100%; ">
        <thead>
            <tr>
                <th></th>

                <th>#</th>
                <th>Tracking Number</th>
                <th>Document Name</th>
                <th>From</th>
                <th>Document Type</th>
                <th>Status</th>
              

            </tr>
        </thead>
    </table>
</div>